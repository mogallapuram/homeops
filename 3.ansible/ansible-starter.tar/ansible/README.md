# 🏡 Ansible Starter Kit — Ram @ ansible

This repository helps you manage your **Ubuntu 25.10**–based homelab using Ansible.

## 🚀 Quick Start

### 1️⃣ Install Ansible
```bash
sudo apt update && sudo apt install -y software-properties-common
sudo add-apt-repository --yes --update ppa:ansible/ansible
sudo apt install -y ansible
ansible --version
```

### 2️⃣ Prepare project
```bash
unzip ansible-starter-ram.zip -d ~/ansible-starter
cd ~/ansible-starter
ansible-galaxy collection install -r requirements.yml
```

### 3️⃣ Edit inventory
```bash
nano inventories/inventory.ini
```
Add your node IPs and confirm the SSH key path `/home/ram/.ssh/id_ed25519`.

### 4️⃣ Test connectivity
```bash
ansible all -m ping
```

### 5️⃣ Apply base setup
```bash
ansible-playbook playbooks/bootstrap.yml
```

✅ Done! Your nodes will now have curl, vim, htop, and correct timezone set.

---
**Author:** Ram @ ansible